package bemformada;

import java.util.Scanner;

/**
 *
 * @author fabio.aglubacheski
 */
public class BemFormada {

    public static void main(String[] args) {
        Scanner ler = new Scanner (System.in);
        String sequencia = "";
        System.out.print("digite uma sequencia de () e []:");
        sequencia=ler.nextLine();
        
        Pilha p = new Pilha(sequencia.length());
        
        for( int i = 0; i < sequencia.length();i++ ){
            if( sequencia.charAt(i)=='(' || sequencia.charAt(i)=='['){
                // empilha o caracter
                p.push(sequencia.charAt(i));
            }
            else{ // so pode ser um fecha ) ou ]
                
                // verifica se a pilha esta vazia antes de desempilhar
                if(p.isEmpty()){
                    System.out.println("Nao esta bem formada");
                    return;
                }
                
                char charTopo = p.pop();
                               
                //verifica a compatibilidade
                if( sequencia.charAt(i) == ')'  && charTopo == '['){ // isso ta errado
                    System.out.println("Nao esta bem formada");
                    return;
                }
                if( sequencia.charAt(i) == ']'  && charTopo == '('){ // isso ta errado
                    System.out.println("Nao esta bem formada");
                    return;
                }
            }
            
        }
        
        // terminei a analise da sequencia a pilha vazia
        if(p.isEmpty())
            System.out.println("Esta bem formada");
        else
            System.out.println("Nao esta bem formada");
    }
    
}
