/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bemformada;

/**
 *
 * @author joao.lslima1
 */
public class Pilha {
    private char elementos[];
    private int topo;
    
    public Pilha(int tam){
        this.elementos = new char[tam];
        this.topo = -1; // pilha         
    }
    
    public void push(char elemento){
        this.topo++;
        this.elementos[topo] = elemento;
    }    
    
    public char pop(){
        char retorno;
        retorno = this.elementos[topo];
        //this.elementos[topo] = ' ';
        this.topo--;
        return retorno;
    }    
    
    public boolean isEmpty(){
        boolean retorno = false;
        if(this.topo == -1){
            retorno = true;
        }
        return retorno;
    }
}
