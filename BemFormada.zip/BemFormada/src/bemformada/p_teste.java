package bemformada;

import java.util.Scanner;

/**
 *
 * @author fabio.aglubacheski
 */
public class p_teste {

    public static void main(String[] args) {
        Scanner ler = new Scanner (System.in);
        String sequencia;
        char Pilha[];
        int topo = -1; // pilha esta vazia eh topo == -1
        System.out.print("digite uma sequencia de () e []:");
        System.out.println("");
        sequencia=ler.nextLine();
        
        Pilha = new char[sequencia.length()];
        for( int i = 0; i < sequencia.length();i++ ){
            
            if( sequencia.charAt(i)=='(' || sequencia.charAt(i)=='['){
                // empilha o caracter
                topo++;
                Pilha[topo] = sequencia.charAt(i); 
            }
            else{ // so pode ser um fecha ) ou ]
                // verifica se a pilha esta vazia antes de desempilhar
                
                char charTopo = Pilha[topo];
                topo--;
                
                if(topo == -1){
                    System.out.println("Nao esta bem formada");
                    return;
                }
                
                //verifica a compatibilidade
                if( sequencia.charAt(i) == ')'  && charTopo == '['){ // isso ta errado
                    System.out.println("Nao esta bem formada");
                    return;
                }
                if( sequencia.charAt(i) == ']'  && charTopo == '('){ // isso ta errado
                    System.out.println("Nao esta bem formada");
                    return;
                }
                
            }
            
        }
        // terminei a analise da sequencia a pilha vazia
        if( topo == -1 )
            System.out.println("Esta bem formada");
        else
            System.out.println("Nao esta bem formada");
    }
    
}
