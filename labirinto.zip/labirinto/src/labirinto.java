import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
/**
 *
 * @author João lucas e Julia Martins
 */
public class labirinto {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        int Ax = 0,Ay = 0;          // variáveis do ponto A
        int Bx = 0,By = 0;          // variáveis do ponto B
        int contadorPontos = 0;     // Variável de indice para inclusão dos pontos recebidos do TXT
        int atual[] =  new int[2];  // Variável auxiliar para o ponto "atual"
        
        FileReader arquivo = new FileReader("arquivo.txt");
        BufferedReader bufferArquivo = new BufferedReader(arquivo);
        
        System.out.println("arquivo aberto corretamente");
        
        String linha = bufferArquivo.readLine(); // lê a primeira linha
        int tamanho = linha.length()/2;
        int mapa[][] = new int[tamanho][tamanho]; // gera o mapa de tamanho NxN
        
        //percorre enquanto a linha não estiver nula
        while (linha != null) {
            //divide a linha atual em um array utilizando " " como separador
            String linhas[] = linha.split(" ");
            //percorre o array da linha atual
            for(int i = 0; i < tamanho ; i++){
                mapa[contadorPontos][i] = Integer.parseInt(linhas[i]);
                //caso seja 1, é o inicio
                if(mapa[contadorPontos][i] == 1){
                    Ax = contadorPontos;
                    Ay = i;
                }
                //caso seja -2, é o destino
                if(mapa[contadorPontos][i] == -2){
                    Bx = contadorPontos;
                    By = i;
                }
            }            
            contadorPontos = contadorPontos + 1;
            linha = bufferArquivo.readLine(); // lê proxima linha
        }
        
        //cria lista
        Lista fila = new Lista();
        //coloca o inicio na lista com a distancia de 1
        fila.inserir(Ax, Ay,1);
        
        //enquanto lista não estiver vazia
        while(!fila.vazia()){
            //mostrando atualizações
            /*
            for(int i = 0; i < tamanho; i++){
                for(int j = 0; j < tamanho ; j++){
                    System.out.print(mapa[i][j] + " ");
                }
                System.out.println("");
            }
            System.out.println("-----------------------------------------------");
            */
            
            //remove da lista e devolve ponto
            atual = fila.remover();
            
            //atualiza no mapa o valor de distancia
            mapa[atual[0]][atual[1]] = atual[2];

            //valida se o ponto acima está dentro do range
            if(atual[0]-1 >= 0){
                //se for valido, insere ele na fila
                if(mapa[atual[0]-1][atual[1]] == 0){
                    fila.inserir(atual[0]-1, atual[1],atual[2] + 1);
                }
                //se for o destino, sai do while.
                if(mapa[atual[0]-1][atual[1]] == -2)
                    break;
            }
            
            //valida se o ponto abaixo está dentro do range
            if(atual[0]+1 < tamanho){
                //se for valido, insere ele na fila
                if (mapa[atual[0]+1][atual[1]] == 0){
                    fila.inserir(atual[0]+1, atual[1],atual[2] + 1);
                }
                //se for o destino, sai do while.
                if (mapa[atual[0]+1][atual[1]] == -2)
                    break;
            }
            
            //valida se o ponto a esquerda está dentro do range
            if(atual[1]-1 >=0){
                //se for valido, insere ele na fila
                if(mapa[atual[0]][atual[1]-1] == 0){
                    fila.inserir(atual[0], atual[1]-1,atual[2] + 1);
                }
                //se for o destino, sai do while.
                if(mapa[atual[0]][atual[1]-1] == -2)
                    break;
            }
            
            //valida se o ponto a direita está dentro do range
            if(atual[1]+1 < tamanho){
                //se for valido, insere ele na fila
                if(mapa[atual[0]][atual[1]+1] == 0){
                    fila.inserir(atual[0], atual[1]+1,atual[2] + 1);
                }
                //se for o destino, sai do while.
                if(mapa[atual[0]][atual[1]+1] == -2)
                    break;
            }
        }
        
        //Se achou, percorre a parte mais perto.
        int menorDist = tamanho * tamanho;
        int sentido = 0;
        
        int atualX = Bx, atualY = By;
        int proxX = Bx, proxY = By;
        
        while(menorDist > 0){
            
            
            //cima
            if(proxX - 1>=0){
                if(mapa[proxX - 1][proxY] < menorDist && mapa[proxX - 1][proxY] > 0){
                    menorDist = mapa[proxX - 1][proxY];
                    sentido = 1;
                }
            }
            //baixo
            if(proxX + 1 < tamanho){
                if(mapa[proxX + 1][proxY] < menorDist && mapa[proxX + 1][proxY] > 0){
                    menorDist = mapa[proxX + 1][proxY];
                    sentido = 2;
                }
            }
            //esquerda
            if(proxY - 1 >= 0){
                if(mapa[proxX][proxY-1] < menorDist && mapa[proxX][proxY - 1] > 0){
                    menorDist = mapa[proxX][proxY-1];
                    sentido = 3;   
                }
            }
            //direita
            if(proxY - 1 < tamanho){
                if(mapa[proxX][proxY+1] < menorDist && mapa[proxX][proxY + 1] > 0){
                    menorDist = mapa[proxX][proxY+1];
                    sentido = 4;   
                }
            }
            
            switch(sentido){
                case 1:
                    proxX--;
                    break;
                case 2:
                    proxX++;
                    break;
                case 3:
                    proxY--;
                    break;
                case 4:
                    proxY++;
                    break;
            }
            
            if (proxX == Ax && proxY == Ay)
                    break;
            
            mapa[proxX][proxY] = -3;
        }
        
        
        //mostrando resultado
        for(int i = 0; i < tamanho; i++){
            for(int j = 0; j < tamanho ; j++){
                if(mapa[i][j] == 1)
                    System.out.print("A" + " ");
                if(mapa[i][j] == -2)
                    System.out.print("B" + " ");
                if (mapa[i][j] > 1)
                    mapa[i][j] = 0;
                if(mapa[i][j] != 1 && mapa[i][j] != -2 && mapa[i][j] != -3)
                    System.out.print(mapa[i][j] + " ");
                if(mapa[i][j] == -3)
                    System.out.print("@" + " ");
            }
            System.out.println("");
        }
        
    }
        
}